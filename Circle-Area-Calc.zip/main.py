import math
def circle_area(radius):
    area= math.pi * (radius**2)

    return area

if __name__=="__main__":
    print("Circle Area Calculator")
    while True:
        user_input=input("Enter a radius between 0 and 1999. Press Enter to exit: ")
        if user_input=="":
            break
        if user_input.isnumeric():
            if 0<=int(user_input)<=1999:
                radius=int(user_input)
                area= circle_area(radius)
                print(f"Radius: {radius}.Area: {area}.")
                
                
            else:
                print(f"Error: {user_input} is out of range.")
        else:
            print(f"Error: {user_input} is not a number.")


      
    

   
      
      
    
  