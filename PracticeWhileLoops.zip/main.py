num=0
score=0
while num!=26:
  user_input=input("Enter the answer to 12+14, or press 's' to skip: ")
  if user_input=='s':
    print("Question skipped. 0 points awarded.")
    break
  else:
    num=int(user_input)
    if num!=26:
      print("Incorrect. Try again.")
    else:
      print("Correct! You have been awarded 1 point!")
      score+=1

print("Next Question...")

while num!=31:
  user_input=input("Enter the answer to 23+8, or press 's' to skip: ")
  if user_input=='s':
    print("Question skipped. 0 points awarded.")
    break
  else:
     num=int(user_input)
     if num!=31:
       print("Incorrect. Try again.")
     else: 
       print("Correct! You have been awarded 1 point!")
       score+=1
print("Next Question...")

while num!=43:
  user_input=input("Enter the answer to 30+13, or press 's' to skip: ")
  if user_input=='s':
    print("Question skipped. 0 points awarded.")
    break
  else:
    num=int(user_input)
    if num!=43:
      print("Incorrect. Try again.")
    else:
      print("Correct! You have been awarded 1 point!")
      score+=1
print("Next Question...")

while num!=44:
  user_input=input("Enter the answer to 17+27, or press 's' to skip: ")
  if user_input=='s':
    print("Question skipped. 0 points awarded.")
    break
  else:
    num=int(user_input)
    if num !=44:
      print("Incorrect. Try again.")
    else:
      print("Correct! You have been awarded 1 point!")
      score+=1
grade = (score/4)*100
print("You received a grade of " + str(round(grade,1)) + "%." )
      
    
  
      
  
       
    
    
  

  



