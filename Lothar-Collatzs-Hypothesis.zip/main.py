# user_input=int(input("Please enter a non-zero and non-negative integer"))

# c0=user_input

# while c0>1:
#   if c0%2==0:
#     c0/=2
#   elif c0%2!=0:
#     c0=3*c0+1
#   print(c0)

def collatz_sequence(n):
    steps = 0  # Initialize the step count
    while n != 1:
        print(n)
        if n % 2 == 0:
            n //= 2
        else:
            n = 3 * n + 1
        steps += 1
    print(1)  # Print the final value of c0 (1)
    return steps

# Input from the user
user_input = int(input("Enter a natural number: "))

if user_input <= 0:
    print("Please enter a non-zero and non-negative integer.")
else:
    total_steps = collatz_sequence(user_input)
    print(f"Number of steps to reach 1: {total_steps}")

    