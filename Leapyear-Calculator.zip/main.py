# def leap_year_finder(year):
#     if year % 4 == 0:
#         if year % 100 != 0 or year % 400 == 0:
#             print("Leap Year")
#             return True
#     print("Not a leap year")
#     return False

# print(leap_year_finder(2000))

#   def leap_year_finder(year):
#       if year % 4 == 0:
#           if year % 100 != 0:
#               print("Leap Year")
#               return True
#           elif year % 400 == 0:
#               print("Leap Year")
#               return True
#       print("Not a leap year")
#       return False

#   print(leap_year_finder(2000))

def leapyear(year):
  if year % 4 == 0:
    if year % 100 == 0:
      if year % 400 == 0:
        print("leap year")
      else:
        print("not a leap year")
    else:
      print("leap year")
  else:
    print("not leap year")

  