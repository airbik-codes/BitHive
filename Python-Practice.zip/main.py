Num1=float(input("Please enter a number: "))
Num2=float(input("Please enter another number: "))
choice=int(input("What operation would you like to perform on the numbers you have provided?\n Press:1 for addition,\n Press 2 for subtraction,\n Press 3 for multiplication,\n Press 4 for division,\n Press 5 for exponentiation. \n "))

if choice == 1:
  print(Num1+Num2)
elif choice == 2:
  print(Num1-Num2)
elif choice == 3:
  print(Num1*Num2)
elif choice == 4:
  print(Num1/Num2)
elif choice == 5:
  print(Num1**Num2)
else:
  print("Please enter a valid choice")