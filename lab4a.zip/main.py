'''
Name: Aakib Kibria Khan
Student_ID: 157802224
'''

import random
secret = random.randint(1, 10)
user_input = 0
while user_input!=secret:
    user_input = input("Guess a number between 1 and 10: ")
    if user_input.isnumeric():
      user_input=int(user_input)            
      if 1<=user_input<=10:
        if user_input != secret:
            print("Sorry, that's not it.")
        else:
             print("Correct! You win.")
      else:
        print("Error: not a number or out of bounds.")
        
        
    
    else:
        print("Error: not a number or out of bounds.")