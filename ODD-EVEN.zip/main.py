user_input=input("Please enter an integer to find out whether it is odd or even: ")

if user_input.isnumeric():
  num1=int(user_input)
  if num1%2==0:
    print("The number is even.")
  else:
    print("The number is odd.")
else:
  print("Error: Please enter a valid integer. ")
  