'''
Function Practice
'''
# def greetings(name):
  
#   return print("Hello,", name)

# greetings("John")

# def sum_generator(num1,num2):
#   total = num1 + num2
#   return total
# print(sum_generator(2,2))

# def even_odd(num):
#   if num%2==0:
#     print("Its even")
#   else: 
#     print("odd")
# even_odd(2)

# def bmi(weight,height):
#   bmi= weight / height **2
#   return bmi


# def lb_kg(lb):
#   kg = lb*0.45359237
#   return kg
# def ft_and_inch_to_m(ft, inch):
#     return ft * 0.3048 + inch * 0.0254


# weight= lb_kg(20)
# height= ft_and_inch_to_m(5,10)

# print(bmi(weight,height))

