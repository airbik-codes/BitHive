import random

question_number=0

score=0

while True:
    
    secret_number1=random.randint(1,10) 
    secret_number2=random.randint(1,10)
    secret= secret_number1 + secret_number2
    question_number+=1
    user_input=input("Enter the answer to " + str(secret_number1) + " + " + str(secret_number2) + ", Press 's' to skip or 'q' to quit: " )
  
    if user_input=='q':
        break
    
    
    elif user_input=='s':
        print("Question skipped. 0 points awarded.")
        continue

    else:
      user_input=int(user_input)
      if user_input!=secret:
        print("Sorry, that's not it.")
      else:
        print("Correct! You have been awarded 1 point!")
        score+=1
        print("Next question...")

result= (score/(question_number-1)) * 100

print("Quiz over. You scored " + str(round(result,1)) + "%." )
   

