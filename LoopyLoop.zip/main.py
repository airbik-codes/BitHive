x=0
while x<=10:
  print(x)
  x+=1
  
print("finished")