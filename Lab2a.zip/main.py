'''
Name: Aakib Kibria Khan
MySeneca ID: akkhan9

'''
user_num1=input("Please enter the first number. ")
user_num2=input("Please enter the second number. ")
user_int1=int(user_num1)
user_int2=int(user_num2)
result= user_int1 + user_int2
print("The result of ", user_num1, "plus" , user_num2 + " is: " , str(result) )