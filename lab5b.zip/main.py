animals=['snake','hamster','scorpion','beaver','mosquito','camel','vulture','horse','python','capybara']
for i in range(1,len(animals),2):
  print(animals[i])