import random
secret=random.randint(1,10)
user_input=0

while user_input!=7:
  user_input=int(input("Guess a number between 1 and 10: "))
  if user_input!=secret:
    print("Sorry, that's not it.")
  else:
    print("Correct! You win.")
  
