import sys
from random import randint

def rolldice():
  random_number1=randint(1,6)
  random_number2=randint(1,6)
  print(f"{random_number1} and {random_number2}")
  total= random_number1 + random_number2
  return int(total)

def getplayers():
  while True:
    user_input= input("Please enter the number of players: ")
    if user_input.isdigit():
      if user_input.startswith('-'):
        print("Invalid input please try again")
      else:
        number_of_players= int(user_input)
        break      
    else:
      print("Invalid input please try again")
  player_number= 1
  counter=0
  player_names=[]
  while counter<number_of_players:
    player=input(f"Please enter player #{player_number} name: ")
    player_number+=1
    counter+=1
    player_names.append(player)
  return player_names

def getrounds():
  while True:
    user_input=input("Please enter how many rounds the players wish to play: ")
    if user_input.isdigit():
      if user_input.startswith('-'):
        print("Invalid input please try again")
      else:
        round_count= int(user_input)
        break
    else:
      print("Invalid input please try again")

  return round_count


def setgame():
  player = getplayers() 
  roundcount = getrounds()
  game=[]
  for i in range(len(player)):
    player_scores = [0] * roundcount
    game.append(player_scores)
  gameset=[game,player,roundcount]
  return gameset

def asktoroll():
    game_set = setgame()  
    game = game_set[0]     
    players = game_set[1]  
    roundcount = game_set[2]  

    scores = []

    for i in range(roundcount):
        for j in range(len(players)):
            print(f"{players[j]}! Hit enter once you are ready to roll your dices!")
            score = rolldice()
            game[j][i]=score
            scores.append(score)
    return scores

def findwinner(game, players):
    gameset = setgame()
    players = gameset[1]
    game = gameset[0]

    highestscore = 0
    winning_players = []
    for i in range(len(players)):
        player_score = sum(game[i])
        if player_score > highestscore:
            highestscore = player_score
            winning_players = [players[i]]
        elif player_score == highestscore:
            winning_players.append(players[i])

    if len(winning_players) == 1:
        return winning_players[0]
    else:
        return ", ".join(winning_players)


def rungame():
  gameset = setgame() 
  game = gameset[0] 
  players = gameset[1] 
  roundcount = gameset[2] 
  printgame(game, players, 0, roundcount) 




def printgame(game, players, roundnumber, roundcount):
    gameset = setgame()
    game = gameset[0]
    players = gameset[1]
    roundcount = gameset[2]

    round_width = 8 + 8 * roundcount

    header = ["Player"] + [f"Round {i+1}" for i in range(roundnumber)] + ["Total"]
    table_width = len(" | ".join(header)) + 2
    print("*" * table_width)
    print(f"{'End of Round':^{round_width}}")
    print(" | ".join(header))
    print("-" * table_width)

    for i in range(len(players)):
        player_scores = [players[i]] + game[i][:roundnumber] + [sum(game[i])]
        
        joined_string = " | ".join([str(score) for score in player_scores])


        print(joined_string)

    print("-" * table_width)
    
    
    total_scores = ["Total"] + [str(sum(game[i][:roundnumber])) for i in range(len(players))] + [""]


    joined_string = " | ".join(total_scores)
    print(joined_string)


    print("*" * table_width)


def rungame():
    while True:
        gameset = setgame()
        game = gameset[0]
        players = gameset[1]
        roundcount = gameset[2]
        
       
        for i in range(len(players)):
            game[i] = [0] * roundcount

        printgame(game, players, 0, roundcount)
        

        for roundnumber in range(roundcount):
            print(f"****************** Round {roundnumber + 1} ******************")
            scores = asktoroll()
            for i in range(len(players)):
                game[i][roundnumber] = scores[i]
            printgame(game, players, roundnumber, roundcount)

        winning_player = findwinner(game, players)
        print(f"Congratulations {winning_player}! You are our WINNER!")

       
        print("Would you like to play another game?")
        print("[1] Yes")
        print("[2] No")
        choice = input("Your choice: ")
        if choice == '2':
            print("Thank you and see you later!")
            break
def game():
   
    rungame() 

if __name__ == "__main__":
    
    game() 




  
    




    
  




  


  
  
            
          

    

 
      
  

  
  
  
  

      
      
  
  
  
      
    
  
  
    

